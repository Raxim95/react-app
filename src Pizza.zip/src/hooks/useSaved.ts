function useSaved() {
  return "saved";
}

export default useSaved;
