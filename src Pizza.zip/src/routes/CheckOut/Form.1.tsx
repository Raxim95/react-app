import React from "react";

export function Form() {
  return <Form>Form</Form>;
}
